
"use strict";

let move_and_confirm = require('./move_and_confirm.js')

module.exports = {
  move_and_confirm: move_and_confirm,
};
